Algorithco brand kit
https://trqsh.uz/brand

FILES

  algorithco-mark-black      The Algorithco mark, for light backgrounds
  algorithco-mark-white      The Algorithco mark, for dark backgrounds
  algorithco-icon            The Algorithco mark on its black tile
  algorithvoice-mark-black   The AlgorithVoice mark, for light backgrounds
  algorithvoice-mark-white   The AlgorithVoice mark, for dark backgrounds
  algorithvoice-icon         The AlgorithVoice mark on its black tile

  Each comes as .svg, which stays sharp at any size, and as .png.
  AlgorithGuard has no mark of its own: write its name.

COLORS

  Ink      #111111
  Paper    #F7F7F5
  White    #FFFFFF
  Yellow   #FFD300

USING THEM

  Use these files as they are to refer to Algorithco and its products.
  Do not redraw, recolor, stretch, rotate or crop the marks, and do not use
  them or our names as part of your own logo, product name or app icon.

  The names and marks belong to Algorithco. The full guidelines, and how to
  reach us about anything they do not cover, are at https://trqsh.uz/brand
